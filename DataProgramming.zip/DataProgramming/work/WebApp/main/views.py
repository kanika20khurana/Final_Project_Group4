from django.shortcuts import render
from main.models import FlowerModel


def home(request):
    data = FlowerModel.objects.all()
    return render(request,'home.html',{"data":data})
