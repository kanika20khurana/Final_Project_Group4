from django.contrib import admin
from main.models import FlowerModel
# Register your models here.
admin.site.register(FlowerModel)
