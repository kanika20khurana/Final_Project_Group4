from django.db import models

# Create your models here.

class FlowerModel(models.Model):
    petal_length = models.FloatField(blank=True,null=True) 
    sepal_length = models.FloatField(blank=True,null=True)
    petal_width = models.FloatField(blank=True,null=True)
    sepal_width = models.FloatField(blank=True,null=True)
    flower_type = models.CharField(max_length=200,blank=True,null=True)

    def __str__(self):
        return self.flower_type


