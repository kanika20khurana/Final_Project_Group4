import requests
import pandas as pd


from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi

dataset_url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
response = requests.get(dataset_url)
csv_data = pd.read_csv(dataset_url)




uri = "mongodb+srv://iris_dataset:iris1234@iriscluster.ndxvqet.mongodb.net/?retryWrites=true&w=majority"
# Create a new client and connect to the server
client = MongoClient(uri, server_api=ServerApi('1'))
# Send a ping to confirm a successful connection
try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print("not successful")
    print(e)

db = client['IrisDatabase']
collection = db['iris']
csv_data.reset_index(inplace=True)
data_dict = csv_data.to_dict("records")
collection.insert_many(data_dict)

